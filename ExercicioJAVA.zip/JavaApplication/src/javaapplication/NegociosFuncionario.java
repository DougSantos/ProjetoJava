/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication;

import java.util.ArrayList;

/**
 *
 * @author Douglas
 */
public class NegociosFuncionario {

    DadosFuncionario dados = DadosFuncionario.obterInstancia();

    public void CadastrarFuncionario(Funcionario f) throws Exception {
        if(f.getNome() == null) {
            throw new Exception("O Nome nao poede ser nulo");
        }
        if (f.getNome().trim().equals("")) {
            throw new Exception("O Nome nao pode ser vazio");
        }
        if (f.getCpf().length() < 11) {
            throw new Exception("O CPF deve conter mais de 11 caracteres");
        }
        if (f.getCpf() == null) {
            throw new Exception("O CPF nao pode ser nulo");
        }
        if (f.getCpf().trim().equals("")) {
            throw new Exception("o CPF nao pode ser vazio");
        }
        if (VerificaCpf(f) == true) {
            throw new Exception("O CPF nao pode ser repetido");
        }
        if (f.getRg() == null) {
            throw new Exception("O RG nao poede ser nulo");
        }

        if (f.getNome().trim().equals("")) {
            throw new Exception("O Nome nao pode ser vazio");
        }

        if (f.getRg().length() < 4) {
            throw new Exception("O RG Informado deve conter mais de 4 caracteres");
        }
        if(VerificaMatricula(f) == true){
            throw new Exception("A Matricula Informada já existe");
        }
            
        dados.CadastrarFuncionario(f);
    }

    public void AlterarFuncionario(int posicao,Funcionario f) throws Exception {
        if(f.getNome() == null) {
            throw new Exception("O Nome nao poede ser nulo");
        }
        if (f.getNome().trim().equals("")) {
            throw new Exception("O Nome nao pode ser vazio");
        }
        if (f.getCpf().length() < 11) {
            throw new Exception("O CPF deve conter mais de 11 caracteres");
        }
        if (f.getCpf() == null) {
            throw new Exception("O CPF nao pode ser nulo");
        }
        if (f.getCpf().trim().equals("")) {
            throw new Exception("o CPF nao pode ser vazio");
        }
        if (f.getRg() == null) {
            throw new Exception("O RG nao poede ser nulo");
        }

        if (f.getNome().trim().equals("")) {
            throw new Exception("O Nome nao pode ser vazio");
        }

        if (f.getRg().length() < 4) {
            throw new Exception("O RG Informado deve conter mais de 4 caracteres");
        }
        dados.AlterarFuncionario(posicao,f);
    }

    public void RemoverFuncionario(int posicao) throws Exception {
        dados.RemoverFuncionario(posicao);
    }

    public ArrayList<Funcionario> ListarFunc() throws Exception {
        return dados.ListarFunc();
    }


    public ArrayList<Funcionario> ListarFuncPrefix(String prefix) throws Exception {
        return dados.ListarFuncPrefix(prefix);
    }

    public ArrayList<Funcionario> ListarFuncSufix(String sufix) throws Exception {
        return dados.ListarFuncSufix(sufix);
        
    }

    public ArrayList<Funcionario> ListarFuncWith(String conteudo) throws Exception {
        return dados.ListarFuncWith(conteudo);
    }
    

    private boolean VerificaMatricula(Funcionario func) throws Exception {
        boolean EstaRep = false;
        for (int i = 0; i < ListarFunc().size(); ++i) {
            if (func.getMatricula() == ListarFunc().get(i).getMatricula()) {
                EstaRep = true;
                break;
            }
        }
        return EstaRep;
    }

    private boolean VerificaCpf(Funcionario func) throws Exception {
        boolean EstaRep = false;
        for (int i = 0; i < ListarFunc().size(); ++i) {
            if (func.getCpf().equals(ListarFunc().get(i).getCpf()) == true) {
                EstaRep = true;
            }
        }
        return EstaRep;
    }


    public int parseNum(String entrada) throws Exception , NumberFormatException {
        if (entrada == null) {
            throw new Exception("Campo com valor nulo");
        } else
            if(isInt(entrada) == true){
                return Integer.parseInt(entrada);
            } else {
                throw new Exception("Informe Apenas Números");
            }
    }
    private boolean isInt(String Numero){
        
        try{
        Integer.parseInt(Numero);
        return true;
        }catch(Exception e){
            return false;
        
        }
    }
}