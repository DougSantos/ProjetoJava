/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication;

import java.util.ArrayList;

/**
 *
 * @author Douglas
 */
public class DadosFuncionario {
    
    private ArrayList<Funcionario> RepoFunc;
    private static DadosFuncionario instancia;
    
    public static DadosFuncionario obterInstancia() {
        if (instancia == null) {
            instancia = new DadosFuncionario();
        }
        return instancia;
    }
    
    private DadosFuncionario() {
        RepoFunc = new ArrayList<>();
    }
    
    public void CadastrarFuncionario(Funcionario f) {
        this.RepoFunc.add(f);
    }
    
    public void AlterarFuncionario(int posicao,Funcionario f) throws Exception {
        
            this.RepoFunc.set(posicao, f);
    }
    
    public void RemoverFuncionario(int posicao) throws Exception {
        
            this.RepoFunc.remove(posicao);
    }
    
    public ArrayList<Funcionario> ListarFunc() throws Exception {
        return (ArrayList<Funcionario>) this.RepoFunc.clone();
    }
    
    public ArrayList<Funcionario> ListarFuncPrefix(String prefix) throws Exception {
        ArrayList<Integer> PosicaoExibicao = new ArrayList<>();
        ArrayList<Funcionario> ArrayExibicao = new ArrayList<>();
        if (this.RepoFunc.isEmpty() == true) {
            throw new Exception("Não há funcionários cadastrados");
        }
        for (int i = 0; i < this.RepoFunc.size(); i++) {
            if (this.RepoFunc.get(i).getNome().startsWith(prefix)) {
                PosicaoExibicao.add(i);
            }
        }
        for (int i = 0; i < PosicaoExibicao.size(); i++) {
            ArrayExibicao.add(this.RepoFunc.get(PosicaoExibicao.get(i)));
        }
        return ArrayExibicao;
    }
    
    public ArrayList<Funcionario> ListarFuncSufix(String sufix) throws Exception {
        ArrayList<Integer> PosicaoExibicao = new ArrayList<>();
        ArrayList<Funcionario> ArrayExibicao = new ArrayList<>();
        if (this.RepoFunc.isEmpty() == true) {
            throw new Exception("Não há funcionários cadastrados");
        }
        for (int i = 0; i < this.RepoFunc.size(); i++) {
            if (this.RepoFunc.get(i).getNome().endsWith(sufix)) {
                PosicaoExibicao.add(i);
            }
        }
        for (int i = 0; i < PosicaoExibicao.size(); i++) {
            ArrayExibicao.add(this.RepoFunc.get(PosicaoExibicao.get(i)));
        }
        return ArrayExibicao;
    }
    
    public ArrayList<Funcionario> ListarFuncWith(String conteudo) throws Exception {
        ArrayList<Integer> PosicaoExibicao = new ArrayList<>();
        ArrayList<Funcionario> ArrayExibicao = new ArrayList<>();
        if (this.RepoFunc.isEmpty() == true) {
            throw new Exception("Não há funcionários cadastrados");
        }
        for (int i = 0; i < this.RepoFunc.size(); i++) {
            if (this.RepoFunc.get(i).getNome().contains(conteudo)) {
                PosicaoExibicao.add(i);
            }
        }
        for (int i = 0; i < PosicaoExibicao.size(); i++) {
            ArrayExibicao.add(this.RepoFunc.get(PosicaoExibicao.get(i)));
        }
        return ArrayExibicao;
    }
}