/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication;

import java.util.ArrayList;

/**
 *
 * @author Douglas
 */
public class Fachada {
    NegociosFuncionario negocio = new NegociosFuncionario();
    
    public void CadastrarFuncionario(Funcionario f) throws Exception{
        negocio.CadastrarFuncionario(f);
        
    }
    public void AlterarFuncionario(int posicao,Funcionario f) throws Exception{
        negocio.AlterarFuncionario(posicao, f);
    }
    public void RemoverFuncionario(int posicao) throws Exception{
        negocio.RemoverFuncionario(posicao);
        
    }
    public ArrayList<Funcionario> ListarFunc() throws Exception{
        return negocio.ListarFunc();
    }
    public ArrayList<Funcionario> ListarFuncPrefix(String prefix) throws Exception{
        return negocio.ListarFuncPrefix(prefix);
        
    }
    public ArrayList<Funcionario> ListarFuncSufix(String sufix) throws Exception{
        return negocio.ListarFuncSufix(sufix);
        
    }
    public ArrayList<Funcionario> ListarFuncWith(String conteudo) throws Exception{
        
       return negocio.ListarFuncWith(conteudo);
        
    }


}